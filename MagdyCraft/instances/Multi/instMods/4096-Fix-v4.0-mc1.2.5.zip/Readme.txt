--- 4096 Fix ---
Minecraft: 1.2.5 Client

--- Installation ---
Prerequisites
- ModLoader
- Minecraft Forge

Move all of the files in this folder into your minecraft.jar
- Install order is: ModLoader -> Minecraft Forge -> 4096 Fix

--- Notes ---
- Avoid IDs 256-385 and 2256-2266 for blocks, as these will overwrite vanilla items
- Avoid IDs lower than 3840 for items for obvious reasons
- Install 4096 fix BEFORE Mystcraft

--- Changelog ---
v2: Added SMP support
v3: Updated to Forge 3.1.3.98
v4: Updated to Forge 3.1.3.101, prevented clients from joining servers without 4096 fix

--- Links/Credits ---
ModLoader - http://www.minecraftforum.net/topic/75440-
Minecraft Forge - http://www.minecraftforum.net/topic/514000-