package gregtechmod.api;

public interface IGregTechDeviceInformation {
	public String getMainInfo();
	public String getSecondaryInfo();
	public String getTertiaryInfo();
	public boolean isGivingInformation();
}
