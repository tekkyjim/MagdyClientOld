package gregtechmod.api;

/**
 * Simple Interface for Machines, which need my Machine Blocks for Multiblockstructures.
 */
public interface IMachineBlockUpdateable {
	/**
	 * The Machine Update
	 */
	public void onMachineBlockUpdate();
}
