package gregtechmod.api;

import net.minecraft.src.ItemStack;

public interface IQuantumChest {
	/**
	 * Is this even a TileEntity of a Quantum Chest. I need things like this Function for MetaTileEntites
	 */
	public boolean isQuantumChest();
	
	/**
	 * Gives an Array of Stacks with Size (of all the Data-stored Items) of the correspondent Item kinds (regular QChests have only one)
	 * Does not include the 66 "ready" Items in the Slots.
	 */
	public ItemStack[] getStoredItemData();
}
