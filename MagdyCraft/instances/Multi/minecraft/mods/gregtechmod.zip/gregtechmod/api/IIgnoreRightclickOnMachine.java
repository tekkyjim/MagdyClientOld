package gregtechmod.api;

public interface IIgnoreRightclickOnMachine {

}
